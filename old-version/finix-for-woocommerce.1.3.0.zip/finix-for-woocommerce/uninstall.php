<?php

// Exit if accessed directly.
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
